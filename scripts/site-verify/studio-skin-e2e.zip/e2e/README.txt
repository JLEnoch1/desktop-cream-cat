精力桌宠 CreamCat · AI 定制皮肤「布丁E2E」

安装（约 1 分钟）：
1. 把整个 e2e 文件夹放进皮肤目录：
   - macOS:   ~/Library/Application Support/CreamCat/skins/
   - Windows: %APPDATA%\CreamCat\skins\
   （也可以在游戏里右键桌面猫 →「打开皮肤文件夹」直达）
2. 把同目录下原来的 default 文件夹改名为 .default（点开头会被忽略），新皮肤即生效。
3. 桌宠约 1 秒内自动热重载；也可右键 →「重新加载皮肤」。

想换回内置精力桌宠：把 .default 改回 default，删除或移走本文件夹即可。

parts/ 内为 12 件 Live2D 式部件拆层稿（脸/头轮廓、左右眼、上下眉毛、嘴巴、
双前爪、身体、尾巴、毛发遮挡层、眼睛高光/阴影层），与姿态帧同一画风、同一只猫。
桌宠 app 不直接消费 parts/，供分层动画制作与画师二创使用。

本皮肤由下载页「AI 毛发定制工坊」生成，素材仅保存在你的电脑上。